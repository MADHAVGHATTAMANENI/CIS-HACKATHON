const state = {
    selectedFile: null,
    files: [],
    versionsByFile: new Map(),
};

const dom = {
    uploadZone: document.getElementById("uploadZone"),
    fileInput: document.getElementById("fileInput"),
    chooseFileButton: document.getElementById("chooseFileButton"),
    uploadButton: document.getElementById("uploadButton"),
    selectedFile: document.getElementById("selectedFile"),
    progressContainer: document.getElementById("progressContainer"),
    progressValue: document.getElementById("progressValue"),
    progressLabel: document.getElementById("progressLabel"),
    filesContent: document.getElementById("filesContent"),
    refreshButton: document.getElementById("refreshButton"),
    toastContainer: document.getElementById("toastContainer"),
    statActiveFiles: document.getElementById("statActiveFiles"),
    statTotalVersions: document.getElementById("statTotalVersions"),
    statStorageUsed: document.getElementById("statStorageUsed"),
    statDuplicateFiles: document.getElementById("statDuplicateFiles"),
    insightsList: document.getElementById("insightsList"),
};

function escapeHtml(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/\"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function formatBytes(value) {
    const bytes = Number(value || 0);
    if (bytes === 0) {
        return "0 B";
    }

    const units = ["B", "KB", "MB", "GB", "TB"];
    const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    const scaled = bytes / (1024 ** index);
    return `${scaled.toFixed(index === 0 ? 0 : 2)} ${units[index]}`;
}

function formatTimestamp(value) {
    if (!value) {
        return "-";
    }

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
        return value;
    }

    return date.toLocaleString();
}

function showToast(message, type = "success") {
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.textContent = message;

    dom.toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 3600);
}

async function requestJson(url, options = {}) {
    const response = await fetch(url, options);
    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
        const error = new Error(data.error || data.message || `Request failed (${response.status})`);
        error.status = response.status;
        throw error;
    }

    return data;
}

function renderStatsSkeleton() {
    [dom.statActiveFiles, dom.statTotalVersions, dom.statStorageUsed, dom.statDuplicateFiles].forEach((el) => {
        el.textContent = "";
        el.classList.add("skeleton", "skeleton-line");
    });
}

function clearStatsSkeleton() {
    [dom.statActiveFiles, dom.statTotalVersions, dom.statStorageUsed, dom.statDuplicateFiles].forEach((el) => {
        el.classList.remove("skeleton", "skeleton-line");
    });
}

function renderFileSkeletons() {
    dom.filesContent.innerHTML = `
        <div class="skeleton skeleton-file"></div>
        <div class="skeleton skeleton-file"></div>
        <div class="skeleton skeleton-file"></div>
    `;
}

function computeStats(files) {
    const activeFiles = files.length;
    const totalVersions = files.reduce((sum, file) => sum + Number(file.totalVersions || 0), 0);
    const totalSize = files.reduce((sum, file) => sum + Number(file.totalSize || 0), 0);
    const duplicateFiles = files.reduce((sum, file) => sum + Math.max(Number(file.totalVersions || 0) - 1, 0), 0);

    return {
        activeFiles,
        totalVersions,
        totalSize,
        duplicateFiles,
    };
}

function buildInsights(stats, files) {
    const insights = [];

    if (stats.totalVersions > 20) {
        insights.push("High change volume detected. Recommended backup frequency: Daily.");
    } else if (stats.totalVersions > 8) {
        insights.push("Moderate change volume detected. Recommended backup frequency: Every 3 days.");
    } else {
        insights.push("Current change volume is low. Recommended backup frequency: Weekly.");
    }

    if (stats.duplicateFiles > 0) {
        insights.push(`${stats.duplicateFiles} duplicate version(s) detected across all files.`);
    } else {
        insights.push("No duplicate versions detected.");
    }

    if (files.length > 0) {
        const largest = [...files].sort((a, b) => Number(b.totalSize || 0) - Number(a.totalSize || 0))[0];
        insights.push(`Largest backup group: ${largest.fileName} (${formatBytes(largest.totalSize)}).`);
    } else {
        insights.push("No files available yet. Upload a file to start building backup history.");
    }

    return insights;
}

function renderStats(stats) {
    clearStatsSkeleton();
    dom.statActiveFiles.textContent = String(stats.activeFiles);
    dom.statTotalVersions.textContent = String(stats.totalVersions);
    dom.statStorageUsed.textContent = formatBytes(stats.totalSize);
    dom.statDuplicateFiles.textContent = String(stats.duplicateFiles);
}

function renderInsights(insights) {
    dom.insightsList.innerHTML = insights
        .map((text) => `<li>${escapeHtml(text)}</li>`)
        .join("");
}

function getEmptyStateMarkup() {
    return `
        <div class="empty-state">
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 7.5l8.25 4.5 8.25-4.5M3.75 7.5L12 3l8.25 4.5M3.75 7.5V16.5L12 21l8.25-4.5V7.5" />
            </svg>
            <p>No files yet</p>
            <p>Upload a file to start version tracking.</p>
        </div>
    `;
}

function renderFiles(files) {
    if (files.length === 0) {
        dom.filesContent.innerHTML = getEmptyStateMarkup();
        return;
    }

    dom.filesContent.innerHTML = files
        .map((file) => {
            const encodedFileName = encodeURIComponent(file.fileName);

            return `
                <article class="file-group" data-file-name="${encodedFileName}">
                    <button class="file-toggle" data-action="toggle" data-file-name="${encodedFileName}" type="button">
                        <span class="file-main">
                            <svg class="chevron" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                <path fill-rule="evenodd" d="M7.21 14.77a.75.75 0 010-1.06L10.94 10 7.21 6.29a.75.75 0 111.06-1.06l4.25 4.24a.75.75 0 010 1.06l-4.25 4.24a.75.75 0 01-1.06 0z" clip-rule="evenodd" />
                            </svg>
                            <span class="file-name">${escapeHtml(file.fileName)}</span>
                        </span>
                        <span class="file-summary">
                            <span class="meta-pill">${Number(file.totalVersions || 0)} version(s)</span>
                            <span class="meta-pill">${formatBytes(file.totalSize || 0)}</span>
                            <span class="meta-pill">${escapeHtml(formatTimestamp(file.lastUpdated))}</span>
                        </span>
                    </button>
                    <div class="versions-panel is-hidden"></div>
                </article>
            `;
        })
        .join("");
}

function renderVersionSkeleton(panel) {
    panel.innerHTML = `
        <div class="skeleton skeleton-line" style="height: 44px;"></div>
        <div class="skeleton skeleton-line" style="height: 44px; margin-top: 8px;"></div>
    `;
}

function renderVersions(filename, versions, panel) {
    if (!versions.length) {
        panel.innerHTML = `<div class="version-cell">No versions available for ${escapeHtml(filename)}.</div>`;
        return;
    }

    panel.innerHTML = versions
        .map((version) => {
            const encodedFileName = encodeURIComponent(filename);
            const encodedVersionId = encodeURIComponent(version.versionId || "");
            const encodedTimestamp = encodeURIComponent(version.timestamp || "");

            return `
                <div class="version-row">
                    <div class="version-cell strong">v${escapeHtml(version.versionNumber)}</div>
                    <div class="version-cell">${escapeHtml(formatTimestamp(version.timestamp))}</div>
                    <div class="version-cell">${formatBytes(version.fileSize || 0)}</div>
                    <div class="version-actions">
                        <button
                            class="btn btn-secondary btn-xs"
                            type="button"
                            data-action="restore"
                            data-file-name="${encodedFileName}"
                            data-version-id="${encodedVersionId}"
                            data-timestamp="${encodedTimestamp}"
                        >Restore Version</button>
                        <button
                            class="btn btn-danger btn-xs"
                            type="button"
                            data-action="delete"
                            data-file-name="${encodedFileName}"
                            data-version-id="${encodedVersionId}"
                        >Delete</button>
                    </div>
                </div>
            `;
        })
        .join("");
}

async function fetchAndRenderVersions(filename, panel) {
    renderVersionSkeleton(panel);

    const response = await requestJson(`/files/${encodeURIComponent(filename)}/versions`);
    const versions = response.versions || [];

    state.versionsByFile.set(filename, versions);
    renderVersions(filename, versions, panel);
}

async function toggleFileGroup(toggleButton) {
    const article = toggleButton.closest(".file-group");
    if (!article) {
        return;
    }

    const encodedFileName = toggleButton.dataset.fileName;
    const filename = decodeURIComponent(encodedFileName);
    const panel = article.querySelector(".versions-panel");

    const opening = panel.classList.contains("is-hidden");
    toggleButton.classList.toggle("open", opening);
    panel.classList.toggle("is-hidden", !opening);

    if (!opening) {
        return;
    }

    if (state.versionsByFile.has(filename)) {
        renderVersions(filename, state.versionsByFile.get(filename), panel);
        return;
    }

    try {
        await fetchAndRenderVersions(filename, panel);
    } catch (error) {
        panel.innerHTML = `<div class="version-cell">Unable to load version history.</div>`;
        showToast(error.message, "error");
    }
}

async function restoreVersion(encodedFileName, encodedVersionId, encodedTimestamp) {
    const filename = decodeURIComponent(encodedFileName);
    const versionId = decodeURIComponent(encodedVersionId || "");
    const timestamp = decodeURIComponent(encodedTimestamp || "");

    const confirmed = window.confirm(`Restore a new latest version from selected history for ${filename}?`);
    if (!confirmed) {
        return;
    }

    try {
        if (versionId) {
            await requestJson(`/files/${encodeURIComponent(filename)}/versions/${encodeURIComponent(versionId)}/restore`, {
                method: "POST",
            });
        } else if (timestamp) {
            await requestJson(`/files/${encodeURIComponent(filename)}/restore/${encodeURIComponent(timestamp)}`, {
                method: "POST",
            });
        } else {
            throw new Error("Missing version identifier for restore.");
        }

        showToast("Version restored successfully.", "success");
        await refreshDashboard();
    } catch (error) {
        showToast(error.message, "error");
    }
}

async function deleteVersion(encodedFileName, encodedVersionId) {
    const filename = decodeURIComponent(encodedFileName);
    const versionId = decodeURIComponent(encodedVersionId || "");

    if (!versionId) {
        showToast("Missing version identifier.", "error");
        return;
    }

    const confirmed = window.confirm(`Delete this version from ${filename}? This cannot be undone.`);
    if (!confirmed) {
        return;
    }

    try {
        await requestJson(`/files/${encodeURIComponent(filename)}/versions/${encodeURIComponent(versionId)}`, {
            method: "DELETE",
        });

        showToast("Version deleted successfully.", "success");
        await refreshDashboard();
    } catch (error) {
        showToast(error.message, "error");
    }
}

function setSelectedFile(file) {
    state.selectedFile = file;

    if (!file) {
        dom.selectedFile.classList.add("is-hidden");
        dom.selectedFile.textContent = "";
        dom.uploadButton.disabled = true;
        return;
    }

    dom.selectedFile.classList.remove("is-hidden");
    dom.selectedFile.textContent = `Selected: ${file.name} (${formatBytes(file.size)})`;
    dom.uploadButton.disabled = false;
}

function resetUploadProgress() {
    dom.progressContainer.classList.add("is-hidden");
    dom.progressValue.style.width = "0%";
    dom.progressLabel.textContent = "0%";
}

function setUploadProgress(percent) {
    dom.progressContainer.classList.remove("is-hidden");
    dom.progressValue.style.width = `${percent}%`;
    dom.progressLabel.textContent = `${percent}%`;
}

function uploadSelectedFile(file) {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        const formData = new FormData();
        formData.append("file", file);

        xhr.open("POST", "/upload", true);

        xhr.upload.onprogress = (event) => {
            if (!event.lengthComputable) {
                return;
            }
            const percent = Math.round((event.loaded / event.total) * 100);
            setUploadProgress(percent);
        };

        xhr.onload = () => {
            const response = (() => {
                try {
                    return JSON.parse(xhr.responseText || "{}");
                } catch (error) {
                    return {};
                }
            })();

            if (xhr.status >= 200 && xhr.status < 300) {
                resolve(response);
                return;
            }

            reject(new Error(response.error || `Upload failed (${xhr.status})`));
        };

        xhr.onerror = () => reject(new Error("Network error during upload."));
        xhr.send(formData);
    });
}

async function handleUpload() {
    if (!state.selectedFile) {
        showToast("Please choose a file before uploading.", "warning");
        return;
    }

    dom.uploadButton.disabled = true;
    dom.chooseFileButton.disabled = true;
    setUploadProgress(0);

    try {
        const response = await uploadSelectedFile(state.selectedFile);
        const duplicateLabel = response.isDuplicate ? " Duplicate content detected." : "";
        showToast(`Upload complete.${duplicateLabel}`, "success");

        state.versionsByFile.clear();
        setSelectedFile(null);
        dom.fileInput.value = "";

        await refreshDashboard();
    } catch (error) {
        showToast(error.message, "error");
    } finally {
        dom.uploadButton.disabled = false;
        dom.chooseFileButton.disabled = false;
        setTimeout(resetUploadProgress, 500);
    }
}

async function refreshDashboard() {
    renderStatsSkeleton();
    renderFileSkeletons();
    state.versionsByFile.clear();

    try {
        const data = await requestJson("/files");
        const files = data.files || [];

        state.files = files;

        const stats = computeStats(files);
        const insights = buildInsights(stats, files);

        renderStats(stats);
        renderInsights(insights);
        renderFiles(files);
    } catch (error) {
        clearStatsSkeleton();
        dom.statActiveFiles.textContent = "-";
        dom.statTotalVersions.textContent = "-";
        dom.statStorageUsed.textContent = "-";
        dom.statDuplicateFiles.textContent = "-";

        dom.filesContent.innerHTML = `
            <div class="empty-state">
                <p>Unable to load dashboard data.</p>
                <p>${escapeHtml(error.message)}</p>
            </div>
        `;

        dom.insightsList.innerHTML = "<li>No insights available while data is unavailable.</li>";
        showToast(error.message, "error");
    }
}

function bindEvents() {
    dom.chooseFileButton.addEventListener("click", () => dom.fileInput.click());

    dom.uploadZone.addEventListener("click", () => dom.fileInput.click());
    dom.uploadZone.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            dom.fileInput.click();
        }
    });

    dom.fileInput.addEventListener("change", () => {
        const file = dom.fileInput.files && dom.fileInput.files[0] ? dom.fileInput.files[0] : null;
        setSelectedFile(file);
    });

    dom.uploadZone.addEventListener("dragover", (event) => {
        event.preventDefault();
        dom.uploadZone.classList.add("dragover");
    });

    dom.uploadZone.addEventListener("dragleave", () => {
        dom.uploadZone.classList.remove("dragover");
    });

    dom.uploadZone.addEventListener("drop", (event) => {
        event.preventDefault();
        dom.uploadZone.classList.remove("dragover");

        const file = event.dataTransfer.files && event.dataTransfer.files[0] ? event.dataTransfer.files[0] : null;
        if (!file) {
            return;
        }

        const transfer = new DataTransfer();
        transfer.items.add(file);
        dom.fileInput.files = transfer.files;
        setSelectedFile(file);
    });

    dom.uploadButton.addEventListener("click", handleUpload);
    dom.refreshButton.addEventListener("click", refreshDashboard);

    dom.filesContent.addEventListener("click", async (event) => {
        const trigger = event.target.closest("[data-action]");
        if (!trigger) {
            return;
        }

        const { action } = trigger.dataset;

        if (action === "toggle") {
            await toggleFileGroup(trigger);
            return;
        }

        if (action === "restore") {
            await restoreVersion(trigger.dataset.fileName, trigger.dataset.versionId, trigger.dataset.timestamp);
            return;
        }

        if (action === "delete") {
            await deleteVersion(trigger.dataset.fileName, trigger.dataset.versionId);
        }
    });
}

bindEvents();
refreshDashboard();
setInterval(refreshDashboard, 30000);
